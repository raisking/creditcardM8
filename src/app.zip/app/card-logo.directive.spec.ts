import { CardLogoDirective } from './card-logo.directive';

describe('CardLogoDirective', () => {
  it('should create an instance', () => {
    const directive = new CardLogoDirective();
    expect(directive).toBeTruthy();
  });
});
